package com.amdocs.mavenspringapp.standalone.model;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class EmployeeMissingSkillSet {
    private String empId;
    private List<String> missingSkills = new ArrayList<>();
    public String getEmpId() {
        return empId;
    }

    public EmployeeMissingSkillSet(String empId, List<String> missingSkills) {
        this.empId = empId;
        this.missingSkills = missingSkills;
    }

    public EmployeeMissingSkillSet() {
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }
    public List<String> getMissingSkills() {
        return missingSkills;
    }
    public void setMissingSkills(List<String> missingSkills) {
        this.missingSkills = missingSkills;
    }
    @Override
    public String toString() {
        return "EmployeeMissingSkillSet{" +
                "empId='" + empId + '\'' +
                ", missingSkills=" + missingSkills +
                '}';
    }
}
