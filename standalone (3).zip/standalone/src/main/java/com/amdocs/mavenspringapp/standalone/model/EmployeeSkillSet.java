package com.amdocs.mavenspringapp.standalone.model;
import java.util.ArrayList;
import java.util.List;

public class EmployeeSkillSet {
    private String empId;
    private List<String> requiredSkills = new ArrayList<>();
    private List<String> actualSkills = new ArrayList<>();

    public EmployeeSkillSet(String empId, List<String> requiredSkills, List<String> actualSkills) {
        this.empId = empId;
        this.requiredSkills = requiredSkills;
        this.actualSkills = actualSkills;
    }

    public EmployeeSkillSet() {
    }

    public String getEmpId() {
        return empId;
    }
    public void setEmpId(String empId) {
        this.empId = empId;
    }
    public List<String> getRequiredSkills() {
        return requiredSkills;
    }
    public void setRequiredSkills(List<String> requiredSkills) {
        this.requiredSkills = requiredSkills;
    }
    public List<String> getActualSkills() {
        return actualSkills;
    }
    public void setActualSkills(List<String> actualSkills) {
        this.actualSkills = actualSkills;
    }
    @Override
    public String toString() {
        return "EmployeeSkillSet{" +
                "empId='" + empId + '\'' +
                ", requiredSkills=" + requiredSkills +
                ", actualSkills=" + actualSkills +
                '}';
    }
}
