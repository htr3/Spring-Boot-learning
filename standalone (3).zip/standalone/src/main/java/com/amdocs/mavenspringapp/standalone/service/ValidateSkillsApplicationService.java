package com.amdocs.mavenspringapp.standalone.service;

import com.amdocs.mavenspringapp.standalone.model.EmployeeMissingSkillSet;
import com.amdocs.mavenspringapp.standalone.model.EmployeeSkillSet;
import org.springframework.beans.factory.annotation.Autowired;

public class ValidateSkillsApplicationService {
    @Autowired
    EmployeeMissingSkillSet employeemissingskillset;
    public EmployeeMissingSkillSet validateSkills(EmployeeSkillSet employeeskillset) {
        employeemissingskillset.setEmpId(employeeskillset.getEmpId());
        employeeskillset.getRequiredSkills().removeIf(skill -> employeeskillset.getActualSkills().stream().anyMatch(skill2 -> skill2.equalsIgnoreCase(skill)));
        employeemissingskillset.setMissingSkills(employeeskillset.getRequiredSkills());
        return employeemissingskillset;
    }
}
