package com.amdocs.mavenspringapp.standalone.controller;

import com.amdocs.mavenspringapp.standalone.model.EmployeeMissingSkillSet;
import com.amdocs.mavenspringapp.standalone.model.EmployeeSkillSet;
import com.amdocs.mavenspringapp.standalone.service.ValidateSkillsApplicationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ValidateSkills {
    ValidateSkillsApplicationService validateSkillsApplicationService;
    @PostMapping("/validateskills")
    public ResponseEntity validateSkills(@RequestBody EmployeeSkillSet employeeSkillset) {
        EmployeeMissingSkillSet employeemissingSkillset = validateSkillsApplicationService.validateSkills(employeeSkillset);
        return new ResponseEntity(employeemissingSkillset, HttpStatus.CREATED);
    }
    @GetMapping("/validateskills")
    public ResponseEntity getResponse(){
        return new ResponseEntity("Hello", HttpStatus.OK);
    }

    @GetMapping("/hello")
    public String Hello() {
        return "Hello Sachin!";
    }
}
