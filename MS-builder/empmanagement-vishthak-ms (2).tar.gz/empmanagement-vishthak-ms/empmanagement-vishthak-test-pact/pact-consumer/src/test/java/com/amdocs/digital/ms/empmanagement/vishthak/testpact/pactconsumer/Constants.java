package com.amdocs.digital.ms.empmanagement.vishthak.testpact.pactconsumer;

public class Constants {

    public static final String THIS_SERVICE = "ThisServiceService";
    public static final String PROVIDER2 = "Provider2Service";

}
