package com.amdocs.digital.ms.empmanagement.vishthak.gateways.services.implementation;

import com.amdocs.digital.ms.empmanagement.vishthak.gateways.services.interfaces.IResourceClassByResourceService;

public class ResourceClassByResourceService implements IResourceClassByResourceService {

    @Override
    public String getResourceTypeFullyQualifiedName(String resourceName) {

        return null;
    }

    @Override
    public String getMappedResourceTypeFullyQualifiedName(String resourceName) {

        return null;
    }

}
