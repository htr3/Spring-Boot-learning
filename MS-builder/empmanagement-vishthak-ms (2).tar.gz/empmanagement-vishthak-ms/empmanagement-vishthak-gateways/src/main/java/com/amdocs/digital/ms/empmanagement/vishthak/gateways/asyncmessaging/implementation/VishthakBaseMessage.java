package com.amdocs.digital.ms.empmanagement.vishthak.gateways.asyncmessaging.implementation;

import com.amdocs.digital.ms.empmanagement.vishthak.gateways.asyncmessaging.interfaces.IVishthakBaseMessage;
import com.amdocs.msb.asyncmessaging.message.BaseMessage;

@SuppressWarnings("squid:CallToDeprecatedMethod")
public abstract class VishthakBaseMessage extends BaseMessage implements IVishthakBaseMessage {
    // add base function implementation here
}
