package com.amdocs.digital.ms.empmanagement.vishthak.gateways.services.interfaces;

public interface IResourceClassByResourceService {

    String getResourceTypeFullyQualifiedName(String resourceName);

    String getMappedResourceTypeFullyQualifiedName(String resourceName);

}
