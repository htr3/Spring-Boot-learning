package com.amdocs.digital.ms.empmanagement.vishthak.gateways.topics;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.SubscribableChannel;

import com.amdocs.msb.asyncmessaging.publish.ITopicPublish;

public interface IVishthakResourcesPublish extends ITopicPublish {
    @Output("Vishthak_Resources_publish")
    @SuppressWarnings("java:S1874")
    SubscribableChannel publish();
}
