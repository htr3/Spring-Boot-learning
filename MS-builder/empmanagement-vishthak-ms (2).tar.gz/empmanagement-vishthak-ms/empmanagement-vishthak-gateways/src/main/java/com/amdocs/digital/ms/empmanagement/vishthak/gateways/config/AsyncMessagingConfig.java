package com.amdocs.digital.ms.empmanagement.vishthak.gateways.config;

import com.amdocs.msb.asyncmessaging.delegate.IDelegate;
import com.amdocs.digital.ms.empmanagement.vishthak.asyncmessages.implementation.RequestEmployeeCountNotification;
import com.amdocs.digital.ms.empmanagement.vishthak.gateways.asyncmessaging.implementation.RequestEmployeeCountNotificationDelegate;
import com.amdocs.digital.ms.empmanagement.vishthak.gateways.asyncmessaging.implementation.PublishEmployeeCountNotificationService;
import com.amdocs.digital.ms.empmanagement.vishthak.business.services.interfaces.IPublishEmployeeCountNotificationService;
import com.amdocs.digital.ms.empmanagement.vishthak.gateways.asyncmessaging.implementation.PublishEmployeeCreatedNotificationService;
import com.amdocs.digital.ms.empmanagement.vishthak.business.services.interfaces.IPublishEmployeeCreatedNotificationService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amdocs.digital.ms.empmanagement.vishthak.gateways.services.implementation.ResourceClassByResourceService;
import com.amdocs.digital.ms.empmanagement.vishthak.gateways.services.interfaces.IResourceClassByResourceService;

@Configuration
public class AsyncMessagingConfig {

    @Bean
    public IDelegate<RequestEmployeeCountNotification> requestEmployeeCountNotificationDelegate() {
        return new RequestEmployeeCountNotificationDelegate();
    }

    @Bean
    public IPublishEmployeeCountNotificationService publishEmployeeCountNotificationService() {
        return new PublishEmployeeCountNotificationService();
    }

    @Bean
    public IPublishEmployeeCreatedNotificationService publishEmployeeCreatedNotificationService() {
        return new PublishEmployeeCreatedNotificationService();
    }

    @Bean
    public IResourceClassByResourceService resourceClassByResourceService() {
        return new ResourceClassByResourceService();
    }
}
