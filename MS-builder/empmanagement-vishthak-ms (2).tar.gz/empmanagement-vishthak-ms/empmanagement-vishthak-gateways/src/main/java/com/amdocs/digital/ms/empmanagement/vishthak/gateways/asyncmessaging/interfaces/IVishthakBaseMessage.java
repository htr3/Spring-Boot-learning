package com.amdocs.digital.ms.empmanagement.vishthak.gateways.asyncmessaging.interfaces;

import com.amdocs.msb.asyncmessaging.message.intf.IBaseMessage;

@SuppressWarnings("squid:CallToDeprecatedMethod")
public interface IVishthakBaseMessage extends IBaseMessage {
    // add base interface function definition here
}
