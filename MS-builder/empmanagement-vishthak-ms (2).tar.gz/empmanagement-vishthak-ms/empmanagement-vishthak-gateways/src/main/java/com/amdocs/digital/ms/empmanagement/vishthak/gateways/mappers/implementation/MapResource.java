package com.amdocs.digital.ms.empmanagement.vishthak.gateways.mappers.implementation;

import com.amdocs.digital.ms.empmanagement.vishthak.gateways.mappers.interfaces.IMapResource;
import com.amdocs.msb.asyncmessaging.message.resource.intf.IResourceBaseMessage;
import com.amdocs.msbase.repository.dto.IBaseEntity;

public class MapResource<T> implements IMapResource<T> {

    @Override
    public IBaseEntity mapResource(IResourceBaseMessage msg) {
        // TODO Auto-generated method stub
        return null;
    }

}
