package com.amdocs.digital.ms.empmanagement.vishthak.gateways.services.implementation;

import javax.inject.Inject;
import com.amdocs.digital.ms.empmanagement.vishthak.business.gateways.interfaces.ISwaggerGatewayGatewayService;
import com.amdocs.digital.ms.swagger.gateway.ck.resources.interfaces.ExternalValidationServiceApi;

public class SwaggerGatewayGatewayService implements ISwaggerGatewayGatewayService {
    @Inject
    private ExternalValidationServiceApi externalValidationServiceApi;
    /*
     * TO DO Add implementations to the gateway-service. Call relevant external Api methods.
     */
}
