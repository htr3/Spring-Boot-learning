package com.amdocs.digital.ms.empmanagement.vishthak.gateways.config;

import com.amdocs.msb.asyncmessaging.subscribe.IHandleMessage;
import com.amdocs.digital.ms.empmanagement.vishthak.asyncmessages.implementation.RequestEmployeeCountNotification;
import com.amdocs.digital.ms.empmanagement.vishthak.gateways.asyncmessaging.implementation.HandleRequestEmployeeCountNotification;
import com.amdocs.digital.ms.empmanagement.vishthak.gateways.topics.IEmployeeCountreqSubscribe;
import com.amdocs.digital.ms.empmanagement.vishthak.gateways.topics.IEmployeeCountPublish;
import org.springframework.context.annotation.Bean;
import com.amdocs.digital.ms.empmanagement.vishthak.gateways.topics.IEmployeeCreationPublish;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.amdocs.digital.ms.empmanagement.vishthak.gateways.topics.IVishthakPublish;
import com.amdocs.digital.ms.empmanagement.vishthak.gateways.topics.IVishthakResourcesPublish;
import com.amdocs.msb.asyncmessaging.config.MsbAsyncMessagingConfig;

@Configuration
@ConditionalOnProperty("spring.cloud.stream.enabled")
@Import({ MsbAsyncMessagingConfig.class })
@EnableBinding({ IVishthakPublish.class, IVishthakResourcesPublish.class, IEmployeeCreationPublish.class,
        IEmployeeCountPublish.class, IEmployeeCountreqSubscribe.class })
@SuppressWarnings("java:S1874")
public class AsyncChannelsConfig {

    @Bean
    public IHandleMessage<RequestEmployeeCountNotification> handleRequestEmployeeCountNotification() {
        return new HandleRequestEmployeeCountNotification();
    }

}
