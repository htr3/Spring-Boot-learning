package com.amdocs.digital.ms.empmanagement.vishthak.gateways.config;

import com.amdocs.digital.ms.empmanagement.vishthak.business.gateways.interfaces.ISwaggerGatewayGatewayService;
import com.amdocs.digital.ms.empmanagement.vishthak.gateways.services.implementation.SwaggerGatewayGatewayService;

import org.springframework.context.annotation.Bean; //NOSONAR
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {
    @Bean
    public ISwaggerGatewayGatewayService getSwaggerGatewayGatewayService() {
        return new SwaggerGatewayGatewayService();
    }
}
