package com.amdocs.digital.ms.empmanagement.vishthak.couchbase.errorhandling.interfaces;

public interface IRepositoryInterceptor {

    public void handleAllErrors(Throwable ex);

}
