package com.amdocs.digital.ms.empmanagement.vishthak.componenttests.config;

import com.amdocs.digital.ms.empmanagement.vishthak.asyncmessages.implementation.RequestEmployeeCountNotification;

import com.amdocs.digital.ms.empmanagement.vishthak.componenttests.delegates.DelegateWithKafka;
import com.amdocs.msb.asyncmessaging.delegate.IDelegate;
import com.amdocs.msbase.testing.component.config.ConfigForCI;
import com.amdocs.msbase.testing.component.delegatewithhttp.DelegateWithHttpProducer;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;

import javax.inject.Inject;
import javax.annotation.PostConstruct;

import com.amdocs.digital.ms.empmanagement.vishthak.ck.resources.interfaces.EmployeeManagementFrameworkApi;
import com.amdocs.digital.ms.empmanagement.vishthak.ck.resources.interfaces.EmpmanagementVishthakServiceApi;

@Configuration
@ConfigForCI

@EnableBinding({ DelegateWithKafka.EmployeeCountreqPublish.class })
public class TestConfigForCI {

    @Bean
    @Primary
    public IDelegate<RequestEmployeeCountNotification> employeeCountreqSubscribe() {
        return DelegateWithKafka.forEmployeeCountreq();
    }

    @Inject
    private DelegateWithHttpProducer delegateProducer;

    @PostConstruct
    public void makeDelegatesWithHttp() {

        Class<?> clientKitInterfaceEmployeeManagementFrameworkApi = EmployeeManagementFrameworkApi.class;
        delegateProducer.makeAndRegisterDelegatesWithHttp(clientKitInterfaceEmployeeManagementFrameworkApi);
        Class<?> clientKitInterfaceEmpmanagementVishthakServiceApi = EmpmanagementVishthakServiceApi.class;
        delegateProducer.makeAndRegisterDelegatesWithHttp(clientKitInterfaceEmpmanagementVishthakServiceApi);
    }
}
