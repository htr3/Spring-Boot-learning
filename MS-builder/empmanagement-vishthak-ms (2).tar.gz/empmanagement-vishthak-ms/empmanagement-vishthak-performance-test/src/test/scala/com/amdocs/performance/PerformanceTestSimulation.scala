package com.amdocs.performance

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import io.gatling.http.protocol.HttpProtocolBuilder
import io.gatling.core.structure.{ ScenarioBuilder => GatlingScenarioBuilder }
import io.gatling.http.protocol.HttpProtocolBuilder.toHttpProtocol

import scalaj.http._
import scalaj.http.HttpResponse
import com.amdocs.performance.config.ScenarioBuilder
import com.amdocs.performance.config.Scenario
import scala.util.parsing.json.JSON
import com.amdocs.performance.config.TokenProvider

import com.typesafe.scalalogging.Logger
import com.amdocs.performance.config.POST
import com.amdocs.performance.config.Scenario
import com.amdocs.performance.config.configProvider
import com.amdocs.performance.config.testSetupConfig


class PerformanceTestSimulation extends Simulation {

  private val logger = Logger( classOf[ PerformanceTestSimulation ] )

  private val RequestBody = "<UPDATE YOUR REQUEST BODY JSON FILE NAME HERE>"
  private val Endpoint = "<UPDATE YOUR ENDPOINT HERE>"
  private val ScenarioName = "<EXPLAIN YOUR SCENARIO NAME HERE>"

 // Sample example simulation for a POST method
 
  var builder = new ScenarioBuilder()
  val testScenario = builder.withMethod( POST )
    .withBody( RequestBody )
    .withBasePath( configProvider.BasePath )
    .withEndpointName( Endpoint )
    .withScenarioName( ScenarioName )
    .build

  val gatlingScnBuilder : GatlingScenarioBuilder = scenario( ScenarioName )
    .exec( testScenario.getScenarioChain )
    .pause( 1 )

  setUp( gatlingScnBuilder.inject( testSetupConfig.getSetup ) )
    .maxDuration( configProvider.StandardDuration )
    .protocols( configProvider.HttpProtocol )
    .assertions(
      //uncomment the assertions that you want to execute//
      
      //global.responseTime.max.lt( 6000 ),
      //global.successfulRequests.percent.gt( 95 ),
      //forAll.successfulRequests.percent.is( 100 )
      //global.responseTime.percentile4.lt( 2000 )
      )
}


