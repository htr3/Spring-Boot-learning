package com.amdocs.digital.ms.empmanagement.vishthak.business.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class BusinessModelsConfig {
}
