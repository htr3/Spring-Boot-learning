package com.amdocs.digital.ms.empmanagement.vishthak.resources.errorhandling.interfaces;

public interface IResourceInterceptor {

    public void handleAllErrors(Throwable ex);

}
