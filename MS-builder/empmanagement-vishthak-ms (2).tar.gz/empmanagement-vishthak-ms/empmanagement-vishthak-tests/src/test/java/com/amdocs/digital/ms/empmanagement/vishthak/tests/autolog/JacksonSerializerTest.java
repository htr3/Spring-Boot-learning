package com.amdocs.digital.ms.empmanagement.vishthak.tests.autolog;

import com.amdocs.digital.ms.empmanagement.vishthak.autolog.JacksonSerializer;
import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
import com.fasterxml.jackson.databind.introspect.AnnotationMap;
import com.fasterxml.jackson.databind.introspect.TypeResolutionContext;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.lang.reflect.Method;

@RunWith(MockitoJUnitRunner.class)
public class JacksonSerializerTest {

    private JacksonSerializer.JsonIgnoreIntrospector jsonIgnoreIntrospector;

    private AnnotatedMethod annotatedMethod;
    private AnnotationMap[] paramAnnotations;
    private AnnotationMap annotationMap;

    @Mock
    private TypeResolutionContext typeResolutionContext;

    private void getMethod(String a) {

    }

    private void createMocks() {

        MockitoAnnotations.initMocks(this);
    }

    @Before
    public void setUp() throws NoSuchMethodException {

        createMocks();
        jsonIgnoreIntrospector = new JacksonSerializer.JsonIgnoreIntrospector();
        paramAnnotations = new AnnotationMap[1];
        annotationMap = new AnnotationMap();
        Method method = this.getClass().getDeclaredMethod("getMethod", String.class);
        method.setAccessible(true);
        annotatedMethod = new AnnotatedMethod(typeResolutionContext, method, annotationMap, paramAnnotations);
    }

    @Test
    public void jacksonSerializerTest() {

        Assert.assertNotNull(jsonIgnoreIntrospector.hasIgnoreMarker(annotatedMethod));
    }
}
