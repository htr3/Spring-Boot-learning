package com.amdocs.commonality.ddulearning.standalone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StandaloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
